INSERT INTO bugtracker.project VALUES (1,'Project Metro','Increase productivity',1, 1);
INSERT INTO bugtracker.project VALUES (2,'Project Ivory','Reduce project time and cost',3, 2);
INSERT INTO bugtracker.project VALUES (3,'Project Apollo','Improve communication between teams',4, 3);
INSERT INTO bugtracker.project VALUES (4,'Project Kodiak','Identify innovative solutions and approaches',3, 4);