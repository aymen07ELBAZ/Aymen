INSERT INTO bugtracker.item VALUES (1, 'Implement Project Apollo', 'Implement the results of Project Apollo', 1, 1, 1);
INSERT INTO bugtracker.item VALUES (2, 'Project Apollo: PIR', 'Conduct a PIR of Project Apollo', 2, 2, 2);
INSERT INTO bugtracker.item VALUES (3, 'Define tasks for Project Metro', 'Define project plan and Roadmap', 4, 2, 3);
INSERT INTO bugtracker.item VALUES (4, 'Fix website bug', 'Test website using different browsers', 3, 4, 4);